"""
kge - A kubectl plugin for viewing Kubernetes events
"""

__version__ = "0.4.1" 