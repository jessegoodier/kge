"""
CLI interface for kubectl get events (kge)
""" 