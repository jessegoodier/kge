class KgeKubectlGetEvents < Formula
  include Language::Python::Virtualenv

  desc "A kubernetes utility for viewing pod events in a user-friendly way"
  homepage "https://github.com/jessegoodier/kge"
  url "https://files.pythonhosted.org/packages/d8/31/ad159d626fbe5f87539598543a67421ad5375df886b7525e101e926f2644/kge_kubectl_get_events-0.4.0.tar.gz"
  sha256 "3b9a5179c64edb5456d8d6d2252675df07f042710324bd24846f829dc43e9c94"
  license "MIT"

  depends_on "python@3.9"

  def install
    virtualenv_install_with_resources
  end

  test do
    system "#{bin}/kge", "--help"
  end
end 